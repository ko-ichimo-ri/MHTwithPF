#!/bin/bash
DIR=check
rm -f ./$DIR/*.log 

../program_final/main ./$DIR/data > ./$DIR/hoges.log


