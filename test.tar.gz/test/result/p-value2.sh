#!/bin/bash
DIR=p-value2
rm -f ./$DIR/*.log ./$DIR/data*

for j in {1..10}
do

../test_data2/main -n 100 -p 1 -m 100 -q 0 -s hoge -L 20 -f ./$DIR/data$j

../program_final/main -a 0.005 -o ./$DIR/nsp.log -O ./$DIR/time.log ./$DIR/data$j > ./$DIR/hoge$j-1.log
echo -n " " >>./$DIR/nsp.log
echo -n " " >>./$DIR/time.log
for i in {2..10};
do
../program_final/main -a 0.0$((i*5)) -o ./$DIR/nsp.log -O ./$DIR/time.log ./$DIR/data$j > ./$DIR/hoge$j-$i.log
echo -n " " >>./$DIR/nsp.log
echo -n " " >>./$DIR/time.log
done

echo -e -n "\n" >>./$DIR/nsp.log
echo -e -n "\n" >>./$DIR/time.log

done
