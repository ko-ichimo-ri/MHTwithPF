name_list<-sub("/","",sub(".","",list.dirs()))
exception<-c("","check","figure","figure_pre")
method<-c("p-value","p-value2")
for (name in name_list){
  if(!match(name,exception,nomatch=0)>0){
    x<-read.table(paste0("./",name,"/nsp.log"))
    y<-read.table(paste0("./",name,"/time.log"))

    png(paste0("./figure/nsp_",name,".png"))
    a<-1:ncol(x)
    b<-as.matrix(colMeans(x))
    if(match(name,method,nomatch=0)>0){
      plot(a,b,xlab="Method",ylab="the number of the detected subsequence",type="l")
    }else{
      plot(a,b,xlab="Database",ylab="the number of the detected subsequence",type="l")
    }
    points(a,b)
    dev.off()

    png(paste0("./figure/time_",name,".png"))
    a<-1:ncol(y)
    b<-as.matrix(colMeans(y))
    if(match(name,method,nomatch=0)>0){
      plot(a,b,xlab="Method",ylab="the execution time [s]",type="l")
    }else{
      plot(a,b,xlab="Database",ylab="the execution time [s]",type="l")
    }
    points(a,b)
    dev.off()
  }
}
