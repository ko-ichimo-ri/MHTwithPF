#!/bin/bash
DIR=letters
rm -f ./$DIR/*.log ./$DIR/data*

LETTERS=actgbdefhijklmnopqrsuvwxyz0123456789
for j in {1..10}
do

for i in {1..9};
do
../test_data/main -n 20 -p 1 -m 20 -q 0 -s actg -L 20 -l ${LETTERS:0:($i*4)} -f ./$DIR/data$j-$i
done

for i in {1..9};
do
../program_final/main -l ${LETTERS:0:($i*4)} -o ./$DIR/nsp.log -O ./$DIR/time.log ./$DIR/data$j-$i > ./$DIR/hoge$j-$i.log
echo -n " " >>./$DIR/nsp.log
echo -n " " >>./$DIR/time.log
done

echo -e -n "\n" >>./$DIR/nsp.log
echo -e -n "\n" >>./$DIR/time.log

done
