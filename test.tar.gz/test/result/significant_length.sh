#!/bin/bash
DIR=sig_len
rm -f ./$DIR/*.log ./$DIR/data*

HOGE=0123456789
for j in {1..10}
do

for i in {1..10};
do
../test_data/main -n 50 -p 1 -m 50 -q 0 -s ${HOGE:0:i} -L 20 -f ./$DIR/data$j-$i
done

for i in {1..10};
do
../program_final/main -o ./$DIR/nsp.log -O ./$DIR/time.log ./$DIR/data$j-$i > ./$DIR/hoge$j-$i.log
echo -n " " >>./$DIR/nsp.log
echo -n " " >>./$DIR/time.log
done

echo -e -n "\n" >>./$DIR/nsp.log
echo -e -n "\n" >>./$DIR/time.log

done
