#ifndef FUNC
#define FUNC
#include "macro.h"
unsigned long combination(unsigned long n,unsigned long r);
void initialized(database db);
void free_db(database db);
void free_p(pattern pattern,int i);
void initialized_p(pattern pattern,int i);
void initialized_allp(pattern pattern,int i);
double l(unsigned int support,unsigned int count0,unsigned int count1);
void prefixspan(int debug,char *s,char let[NUMBER_LETTER],unsigned int total,database db,unsigned int minsup,unsigned int *pointer_num_minsup, pattern pattern);
void print_result(char let[NUMBER_LETTER],pattern pattern,unsigned int num_minsup,double alpha,unsigned int minsup,unsigned int total,unsigned int count0,unsigned int count1,database db,database db_v1,int debug);

#endif
