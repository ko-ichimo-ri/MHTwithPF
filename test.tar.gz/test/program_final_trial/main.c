#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <math.h>
#include <time.h>
#include "macro.h"
#include "func.h"
extern long double comb[NUMBER_COMB][NUMBER_COMB];

int main(int argc,char **argv){
  extern char *optarg;
  extern int optind;
  int opt;
  int debug=0;
  double alpha=0.05;

  char let[NUMBER_LETTER];//解析する文字
  strcpy(let,"abcdefghijklmnopqrstuvwxyz1234567890");

  unsigned int count0=0;//与えられたデータで目的変数が0のものの個数（P値の下限を計算する時に用いる）
  unsigned int count1=0;//与えられたデータで目的変数が1のものの個数（P値の下限を計算する時に用いる）

unsigned int n_comb,r_comb;
for(n_comb=0;n_comb < NUMBER_COMB;n_comb++){
  for(r_comb=0;r_comb < NUMBER_COMB;r_comb++){
    if(n_comb==r_comb){
      comb[n_comb][r_comb]=1;
    }else if(r_comb==0){
      comb[n_comb][r_comb]=1;
    }else if(r_comb==1){
      comb[n_comb][r_comb]=n_comb;
    }else{
      comb[n_comb][r_comb]=0;
    }
  }
}


  while((opt=getopt(argc,argv,"dl:a:"))!=EOF){
    switch(opt){
      case 'l':
        strcpy(let,optarg);
        break;
      case 'a':
        alpha=atof(optarg);
        break;
      case 'd':
        debug=1;
      break;

      default:
        break;
    }
  }
  printf("letters: %s\nalpha: %lf\n",let,alpha);
  if(debug){
    printf("debug: on\n");
  }else{
    printf("debug: off\n");
  }
  if(debug){
    printf("argv[optind]: %s\n",argv[optind]);
  }

  clock_t start,end;
  start=clock();
  FILE *fp;
  if((fp=fopen(argv[optind],"r"))==NULL){
    printf("file '%s' open error\n", argv[1]);
    exit(EXIT_FAILURE);
  }

  char s[LENGTH_DATA];

  database db;
  database db_v1;
  initialized(db);
  initialized(db_v1);
  int i=0;
  
  while(fgets(s,LENGTH_DATA,fp)){
    if(s[0]=='0'){
      count0++;
    }else if(s[0]=='1'){
      count1++;
      strcpy(db_v1[i],&s[2]);
    }else{
      perror("error!\n");
      exit(EXIT_FAILURE);
    }
    strcpy(db[i],&s[2]);
    i++;
  }

  unsigned int minsup;
  unsigned int num_minsup=0;
  unsigned int total = count0+count1;
  pattern pattern;
  
  pattern=malloc(sizeof(char *));  

  for(minsup=total;minsup>0;minsup--){
    if(debug){
       printf("minsup=%d\n",minsup);
    }
// 初期化
    num_minsup=0;
//prefixspan
    if(debug){
      printf("before prefixspan\n");
    }
    prefixspan(debug,"",let,total,db,minsup,&num_minsup,pattern);
    if(debug){
      printf("after prefixspan\n");
      printf("before calculating ``l''\n");
    }

//Tarone
    if(l(minsup-1,count0,count1)*num_minsup>alpha){
      if(debug){
        printf("after calculating ``l''\n");
      }
      print_result(let,pattern,num_minsup,alpha,minsup,total,count0,count1,db,db_v1,debug);
      break;
    }else if(debug){
      printf("after calculating ``l''\n");
    }

    if(debug){
      printf("before initialized_allp\n");
    }
    initialized_allp(pattern,num_minsup);
    if(debug){
      printf("after initialized_allp\n");
    }

  }
  end=clock();
//  free_db(db);
//  free_db(db_v1);
//  free_p(pattern,pattern_length); 最後なのでfree()はOSに任せた！
  printf("\ntime: %lf seconds\n",(double)(end-start)/CLOCKS_PER_SEC);

  return 0;
}

