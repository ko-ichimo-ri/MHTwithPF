#ifndef MACRO
#define MACRO

#define LENGTH_DATA 8192
#define NUMBER_DATA 16384
#define NUMBER_LETTER 256

#endif
