#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <math.h>
#include <time.h>
#include "macro.h"
//dbのfreeをやる

int main(int argc,char **argv){
  extern char *optarg;
  extern int optind;
  int opt,n=10,m=10,L=10;
  double p=0.0,q=0.0;
//  int debug=0;

  char let[NUMBER_LETTER];//解析する文字
  strcpy(let,"abcdefghijklmnopqrstuvwxyz1234567890");
  char subseq[NUMBER_LETTER]="";
  char file_name[NUMBER_LETTER]="data";
  int count0=0;//与えられたデータで目的変数が0のものの個数（P値の下限を計算する時に用いる）
  int count1=0;//与えられたデータで目的変数が1のものの個数（P値の下限を計算する時に用いる）

  while((opt=getopt(argc,argv,"l:f:s:p:q:n:m:L:d"))!=EOF){
    switch(opt){
      case 'l':
        strcpy(let,optarg);
        break;
      case 'f':
        strcpy(file_name,optarg);
        break;

      case 's': 
        strcpy(subseq,optarg);
        break;
      case 'p':
        p=atof(optarg); //the probability of appearance of s on data 1
        break;
      case 'q':
        q=atof(optarg); ////the probability of appearance of s on data 1
        break;

      case 'n':
        n=atoi(optarg); //the number of data 1 on database
        break;
      case 'm':
        m=atoi(optarg); //the number of data 0 on database
        break;

      case 'L':
        L=atoi(optarg); //the length of data
        break;

//      case 'd':
//        debug=1;
      break;

      default:
        break;
    }
  }

  FILE *fp;
  if ((fp = fopen(file_name, "w")) == NULL) {
    fprintf(stderr, "%sのオープンに失敗しました.\n", file_name);
    exit(EXIT_FAILURE);
  }

  int i;
  int let_len = strlen(let);
  srand((unsigned)time(NULL));
  for(count1=0;count1<n;count1++){
    if(count1<n*p){
      fprintf(fp,"1 %s",subseq);     
      for(i=0;i<L-strlen(subseq);i++){
        fprintf(fp,"%c",let[rand()%let_len]);
      }
      fprintf(fp,"\n");
    }else{
      fprintf(fp,"1 ");
      for(i=0;i<L;i++){
        fprintf(fp,"%c",let[rand()%let_len]);
      }
      fprintf(fp,"\n");
    }
  }  

  for(count0=0;count0<m;count0++){
    if(count0<m*q){
      fprintf(fp,"0 %s",subseq);     
      for(i=0;i<L-strlen(subseq);i++){
        fprintf(fp,"%c",let[rand()%let_len]);
      }
      fprintf(fp,"\n");
    }else{
      fprintf(fp,"0 ");
      for(i=0;i<L;i++){
        fprintf(fp,"%c",let[rand()%let_len]);
      }
      fprintf(fp,"\n");
    }
  }  

  return 0;
}

