#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <math.h>
#include <time.h>
#include "macro.h"
//dbのfreeをやる

int check_int(int n,int *sub_num_list,int sub_len){
  int i;
  for(i=0;i<sub_len;i++){
    if(sub_num_list[i]==n) return 1;
  }
  return 0;
}

int main(int argc,char **argv){
  extern char *optarg;
  extern int optind;
  int opt,n=10,m=10,L=10;
  double p=0.0,q=0.0;
//  int debug=0;

  char let[NUMBER_LETTER];//解析する文字
  strcpy(let,"abcdefghijklmnopqrstuvwxyz1234567890");
  char subseq[NUMBER_LETTER]="";
  char file_name[NUMBER_LETTER]="data";
  int count0=0;//与えられたデータで目的変数が0のものの個数（P値の下限を計算する時に用いる）
  int count1=0;//与えられたデータで目的変数が1のものの個数（P値の下限を計算する時に用いる）

  while((opt=getopt(argc,argv,"l:f:s:p:q:n:m:L:d"))!=EOF){
    switch(opt){
      case 'l':
        strcpy(let,optarg);
        break;
      case 'f':
        strcpy(file_name,optarg);
        break;

      case 's': 
        strcpy(subseq,optarg);
        break;
      case 'p':
        p=atof(optarg); //the probability of appearance of s on data 1
        break;
      case 'q':
        q=atof(optarg); ////the probability of appearance of s on data 1
        break;

      case 'n':
        n=atoi(optarg); //the number of data 1 on database
        break;
      case 'm':
        m=atoi(optarg); //the number of data 0 on database
        break;

      case 'L':
        L=atoi(optarg); //the length of data
        break;

//      case 'd':
//        debug=1;
      break;

      default:
        break;
    }
  }

  FILE *fp;
  if ((fp = fopen(file_name, "w")) == NULL) {
    fprintf(stderr, "%sのオープンに失敗しました.\n", file_name);
    exit(EXIT_FAILURE);
  }

  int i;
  int let_len = strlen(let);
  int sub_len = strlen(subseq);
  int subseq_count;
  int *sub_num_list;
  sub_num_list=malloc(sizeof(int));
  for(i=0;i<sub_len;i++)
    sub_num_list[i]=-1;
  srand((unsigned)time(NULL));
  int i_sub=0;
  int r_sub;
  for(count1=0;count1<n;count1++){
    if(count1<n*p){
      i_sub=0;
      while(i_sub<sub_len){
        r_sub=rand()%L;
        if(1-check_int(r_sub,sub_num_list,sub_len)){
          sub_num_list[i_sub]=r_sub;
          i_sub++;
        }
      }
      subseq_count=0;
      fprintf(fp,"1 ");     
      for(i=0;i<L;i++){
        if(check_int(i,sub_num_list,sub_len)){
          fprintf(fp,"%c",subseq[subseq_count]);
          subseq_count++;
        }else{
          fprintf(fp,"%c",let[rand()%let_len]);
        }
      }
      fprintf(fp,"\n");
    }else{
      fprintf(fp,"1 ");
      for(i=0;i<L;i++){
        fprintf(fp,"%c",let[rand()%let_len]);
      }
      fprintf(fp,"\n");
    }
  }  

  for(count0=0;count0<m;count0++){
    if(count0<m*q){
      i_sub=0;
      while(i_sub<sub_len){
        r_sub=rand()%L;
        if(1-check_int(r_sub,sub_num_list,sub_len)){
          sub_num_list[i_sub]=r_sub;
          i_sub++;
        }
      }
      subseq_count=0;
      fprintf(fp,"0 ");     
      for(i=0;i<L;i++){
        if(check_int(i,sub_num_list,sub_len)){
          fprintf(fp,"%c",subseq[subseq_count]);
          subseq_count++;
        }else{
          fprintf(fp,"%c",let[rand()%let_len]);
        }
      }
      fprintf(fp,"\n");
    }else{
      fprintf(fp,"0 ");
      for(i=0;i<L;i++){
        fprintf(fp,"%c",let[rand()%let_len]);
      }
      fprintf(fp,"\n");
    }
  }  

  return 0;
}

