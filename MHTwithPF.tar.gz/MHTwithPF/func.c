#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <math.h>
#include "macro.h"

extern long double comb[NUMBER_COMB][NUMBER_COMB];

long double combination(unsigned long n,unsigned long r){
  if(n<r){
    return 0;
  }else if(comb[n][r]==0){
    comb[n][r]=combination(n-1, r-1) + combination(n-1, r);
  }
  return comb[n][r];
} 

void initialized(database db){
  int i;
  for(i=0;i<NUMBER_DATA;i++){
     db[i]=calloc(LENGTH_DATA,sizeof(char));
//     for(j=0;j<LENGTH_DATA;j++)
//      db[i][j]='\0';
  }
};
void initialized2(database db){
  int i;
  for(i=0;i<NUMBER_DATA;i++){
      db[i]=NULL;
  }
};


void free_db(database db){
  int i;
  for(i=0;i<NUMBER_DATA;i++){
     if(db[i]!=NULL)free(db[i]);
  }
};

void initialized_p(pattern pattern,int i){
    pattern[i]=calloc(LENGTH_DATA,sizeof(char));
};

void initialized_allp(pattern pattern,int i){
    int j;
    for(j=0;j<i;j++){
        free(pattern[j]);
//        free(pattern);
    }
//    pattern=malloc(sizeof(char *));
}

void free_p(pattern pattern,int i){
    int j;
    for(j=0;j<i;j++){
        free(pattern[j]);
    }
    free(pattern);
}

double l(unsigned long support,unsigned long count0,unsigned long count1){
  double l;
  unsigned long total = count0+count1;
  if(support<=count1){
    l=combination(count1,support)/(double)combination(total,support);
  }else{
    l=1/(long double)combination(total,count1);
//    l=combination(count0,support-count1)/(double)combination(count0+count1,support);<-間違い！
//support=count1とせよ！
  }
  return l;
};
void prefixspan(int debug,char *s,char let[NUMBER_LETTER],unsigned int total,database db,unsigned int minsup,unsigned int *pointer_num_minsup, pattern pattern){
  int i,j;
  unsigned int support;
  char *p_char;
  database projected_db;

  if(debug){
    printf("before initialized\n");
  }

  initialized(projected_db);

  if(debug){
    printf("after initialized\n");
  }

  unsigned int pnm;

  for(i=0;let[i]!='\0' && i<NUMBER_LETTER;i++){
    if(debug){
      printf("before initialized2\n");
    }
    initialized2(projected_db);
    if(debug){
      printf("after initialized2\n");
    }

    pnm=*pointer_num_minsup;
    support=0;
    for(j=0;j<total;j++){
      p_char=strchr(db[j],(int)let[i]);
      if(p_char!=NULL){
        projected_db[support]=p_char+1;//書き換えるかも
        support++;
      }
    }
    if(debug){
      printf("%s%c; support=%d\n",s,let[i],support);
    }

    if(support>=minsup){
      initialized_p(pattern,pnm);
      strcpy(pattern[pnm],s);
      pattern[pnm][strlen(s)]=let[i];
      pattern[pnm][strlen(s)+1]='\0';
      if(debug){
         printf("pattern[%d]=%s\n",pnm,pattern[pnm]);
         printf("support=%d\n",support);
      }
      (*pointer_num_minsup)++;

      prefixspan(debug,pattern[pnm],let,support,projected_db,minsup,pointer_num_minsup,pattern);
    }
  }
};

int count_support(char *s,database db,unsigned int total,int debug){
  unsigned int i,j,support=0;
  unsigned int length=strlen(s);
  char *cp;
  for(i=0;i<total;i++){
    cp=db[i];
    for(j=0;j<length;j++){
      cp=strchr(cp,(int)s[j]);
      if(cp==NULL){
         break;
      }else{
         cp++;
      }
    }
    if(j==length)support++;
  }   
  if(debug)printf("support=%d\n",support);
  return support;
}

double p_value(char *s,database db,database db_v1,int count0,int count1,int debug){
  long double pre_p=0.0;
  unsigned long total=count0+count1;
  unsigned long i,support,support_v1;
  if(debug)printf("%s\ndb: ",s);
  support=count_support(s,db,total,debug);
  if(debug)printf("db_v1: ");
  support_v1=count_support(s,db_v1,total,debug);
    if(debug)printf("now pre_p: %Lf\n", pre_p);//debug
  for(i=support_v1;i<= support && i<= count1;i++){
    pre_p=pre_p+combination(count1,i)*combination(count0,support-i);
    if(debug)printf("now pre_p: %Lf(=pre_p+(%Lf*%Lf))\n", pre_p,combination(count1,i),combination(count0,support-i));//debug
  }
  if(debug)printf("p=%Lf/%Lf\n", pre_p,combination(total,support));//debug
  long double p=pre_p/combination(total,support);
  return p;
};

void print_result(char let[NUMBER_LETTER],pattern pattern,unsigned int num_minsup,double alpha,unsigned int minsup,unsigned int total,unsigned int count0,unsigned int count1,database db,database db_v1,int debug,FILE *fp_nsp){
  int i,count_sig;
  long double p;
  long double delta=alpha/(long double)num_minsup;
  printf("letters: %s\n",let);//いらないかも
  printf("total: %d\n0: %d\n1: %d\n",total,count0,count1);//いらないかも
  printf("delta: %LE\nthe number of frequent patterns: %d\n",delta,num_minsup);
  if(debug)
  printf("minsup: %d\nl(minsup-1): %lf\nl(minsup): %lf\n",minsup,l(minsup-1,count0,count1),l(minsup,count0,count1));

  if(1-debug)printf("\nStatistical significant data:\n");
  for(i=0;i<num_minsup;i++){
    p=p_value(pattern[i],db,db_v1,count0,count1,debug);
    if(debug){
      printf("pattern[%d]=%s\np_value: %LE; reject? ",i,pattern[i],p);
      if(p<delta){
        printf("Yes;\n\n");
      }else{
        printf("No;\n\n");
      }
    }else{
      if(p<delta){
        count_sig++;
        printf("\"%s\": p_value: %LE\n",pattern[i],p);
      }
    }
  }
  printf("\nthe number of significant patterns: %d\n",count_sig);

  if(fp_nsp != NULL){
    fprintf(fp_nsp,"%d ",count_sig);
  }
}
