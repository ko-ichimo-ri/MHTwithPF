#ifndef MACRO
#define MACRO

#define LENGTH_DATA 128
#define NUMBER_DATA 1024
#define NUMBER_LETTER 128
#define NUMBER_COMB 1024
long double comb[NUMBER_COMB][NUMBER_COMB];

typedef char **pattern;
typedef char *database[NUMBER_DATA];
#endif
